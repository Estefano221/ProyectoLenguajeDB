/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Models.HerramientasClass;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class HerramientasDAO {

    private Connection connection;

    public HerramientasDAO(Connection connection) {
        this.connection = connection;
    }

    public List<HerramientasClass> obtenerTodasLasHerramientas() throws SQLException {
        List<HerramientasClass> herramientasList = new ArrayList<>();

        String query = "SELECT * FROM herramientas";
        try (PreparedStatement statement = connection.prepareStatement(query); ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                HerramientasClass herramienta = new HerramientasClass();
                herramienta.setId(resultSet.getInt("ID_HERRAMIENTA"));
                herramienta.setNombre(resultSet.getString("NOMBRE"));
                herramienta.setTipo(resultSet.getString("TIPO_HERRAMIENTA"));
                herramienta.setUso(resultSet.getString("USO_HERRAMIENTA"));
                herramientasList.add(herramienta);
            }
        }
        return herramientasList;
    }

    public void insertarHerramienta(HerramientasClass herramienta) throws SQLException {
        String query = "INSERT INTO herramientas (NOMBRE, TIPO_HERRAMIENTA, USO_HERRAMIENTA) VALUES (?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, herramienta.getNombre());
            statement.setString(2, herramienta.getTipo());
            statement.setString(3, herramienta.getUso());
            statement.executeUpdate();
        }
    }

    public void actualizarHerramienta(HerramientasClass herramienta) throws SQLException {
        String query = "UPDATE herramientas SET NOMBRE = ?, TIPO_HERRAMIENTA = ?, USO_HERRAMIENTA = ? WHERE ID_HERRAMIENTA = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, herramienta.getNombre());
            statement.setString(2, herramienta.getTipo());
            statement.setString(3, herramienta.getUso());
            statement.setInt(4, herramienta.getId());
            statement.executeUpdate();
        }
    }

    public void borrarHerramienta(int idHerramienta) throws SQLException {
        String query = "DELETE FROM herramientas WHERE ID_HERRAMIENTA = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, idHerramienta);
            statement.executeUpdate();
        }
    }

    public HerramientasClass buscarHerramientaPorCodigo(int codigo) throws SQLException {
        String query = "SELECT * FROM herramientas WHERE CODIGO = ?";

        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, codigo);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    HerramientasClass herramienta = new HerramientasClass();
                    herramienta.setCodigo(resultSet.getInt("CODIGO"));
                    herramienta.setNombre(resultSet.getString("NOMBRE"));
                    herramienta.setTipo(resultSet.getString("TIPO_HERRAMIENTA"));
                    herramienta.setUso(resultSet.getString("USO_HERRAMIENTA"));
                    return herramienta;
                }
            }
        }

        return null; 
    }
}
