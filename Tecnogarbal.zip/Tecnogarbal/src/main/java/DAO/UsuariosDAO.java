package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import Models.UsuariosClass;
import lbd.tecnogarbal.ConexionBD;
import java.lang.String;

public class UsuariosDAO {

    public static List<UsuariosClass> obtenerlUsuarios() throws SQLException {
        List<UsuariosClass> usuariosList = new ArrayList<>();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = ConexionBD.obtenerConexion();
            String query = "SELECT * FROM USUARIOS";
            preparedStatement = connection.prepareStatement(query);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int idUsuario = resultSet.getInt("ID_USUARIO");
                int idMateriales = resultSet.getInt("ID_MATERIALES");
                int contrasenia = resultSet.getInt("CONTRASEÑA");
                int confContrasenia = resultSet.getInt("CONTRASEÑA");
                String nombre = resultSet.getString("NOMBRE");
                int telefono = resultSet.getInt("TELEFONO");
                String email = resultSet.getString("EMAIL");

                UsuariosClass usuario = new UsuariosClass(idUsuario, idMateriales, contrasenia, confContrasenia, nombre, telefono, email);
                usuariosList.add(usuario);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (resultSet != null) {
                resultSet.close();
            }
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (connection != null) {
                connection.close();
            }
        }

        return usuariosList;
    }

    public UsuariosDAO(String nombre, String telefono, String email, String contrasenia, String confContrasenia) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void insertarUsuario(UsuariosClass usuario) throws SQLException {
        String consulta = "INSERT INTO USUARIOS (ID_MATERIALES, CONTRASEÑA, NOMBRE, TELEFONO, EMAIL) "
                + "VALUES (?, ?, ?, ?, ?)";

        try (Connection conexion = ConexionBD.obtenerConexion(); PreparedStatement consultaPreparada = conexion.prepareStatement(consulta)) {

            consultaPreparada.setInt(1, usuario.getIdMateriales());
            consultaPreparada.setInt(2, usuario.getContrasenia());
            consultaPreparada.setString(3, usuario.getNombre());
            consultaPreparada.setInt(4, usuario.getTelefono());
            consultaPreparada.setString(5, usuario.getEmail());

            consultaPreparada.executeUpdate();
        }
    }

    public void actualizarUsuario(UsuariosClass usuario) throws SQLException {
        String consulta = "UPDATE USUARIOS SET ID_MATERIALES=?, CONTRASEÑA=?, NOMBRE=?, TELEFONO=?, EMAIL=? "
                + "WHERE ID_USUARIO=?";

        try (Connection conexion = ConexionBD.obtenerConexion(); PreparedStatement consultaPreparada = conexion.prepareStatement(consulta)) {

            consultaPreparada.setInt(1, usuario.getIdMateriales());
            consultaPreparada.setInt(2, usuario.getContrasenia());
            consultaPreparada.setString(3, usuario.getNombre());
            consultaPreparada.setInt(4, usuario.getTelefono());
            consultaPreparada.setString(5, usuario.getEmail());
            consultaPreparada.setInt(6, usuario.getIdUsuario());

            consultaPreparada.executeUpdate();
        }
    }

    public void eliminarUsuario(int idUsuario) throws SQLException {
        String consulta = "DELETE FROM USUARIOS WHERE ID_USUARIO=?";

        try (Connection conexion = ConexionBD.obtenerConexion(); PreparedStatement consultaPreparada = conexion.prepareStatement(consulta)) {

            consultaPreparada.setInt(1, idUsuario);

            consultaPreparada.executeUpdate();
        }
    }
}
