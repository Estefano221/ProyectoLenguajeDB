/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Models.MantenimientoClass;
import Views.Mantenimiento;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author FMP
 */
public class MantenimientoDAO {
    
     private Connection connection;

    public MantenimientoDAO(Connection connection) {
        this.connection = connection;
    }

    public boolean insertMantenimiento(MantenimientoClass mantenimiento) {
        String query = "INSERT INTO MANTENIMIENTO (ID_HERRAMIENTA, FECHA_INGRESO, FECHA_EGRESO) VALUES (?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, mantenimiento.getIdHerramienta());
            statement.setDate(2, mantenimiento.getFechaIngreso());
            statement.setDate(3, mantenimiento.getFechaEgreso());

            int rowsInserted = statement.executeUpdate();
            return rowsInserted > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean actualizarMantenimiento(MantenimientoClass mantenimiento) {
        String query = "UPDATE MANTENIMIENTO SET FECHA_INGRESO = ?, FECHA_EGRESO = ? WHERE ID_HERRAMIENTA = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setDate(1, mantenimiento.getFechaIngreso());
            statement.setDate(2, mantenimiento.getFechaEgreso());
            statement.setInt(3, mantenimiento.getIdHerramienta());

            int rowsUpdated = statement.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean eliminarMantenimiento(int idHerramienta) {
        String query = "DELETE FROM MANTENIMIENTO WHERE ID_HERRAMIENTA = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, idHerramienta);

            int rowsDeleted = statement.executeUpdate();
            return rowsDeleted > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<MantenimientoClass> buscarPorCodigo(String codigoBuscado) {
    List<MantenimientoClass> resultados = new ArrayList<>();
    String query = "SELECT * FROM MANTENIMIENTO WHERE ID_HERRAMIENTA = ?";
    try (PreparedStatement statement = connection.prepareStatement(query)) {
        statement.setString(1, codigoBuscado);
        ResultSet resultSet = statement.executeQuery();
        
        while (resultSet.next()) {
            int idHerramienta = resultSet.getInt("ID_HERRAMIENTA");
            Date fechaIngreso = resultSet.getDate("FECHA_INGRESO");
            Date fechaEgreso = resultSet.getDate("FECHA_EGRESO");

            MantenimientoClass mantenimiento = new MantenimientoClass();
            mantenimiento.setIdHerramienta(idHerramienta);
            mantenimiento.setFechaIngreso(fechaIngreso);
            mantenimiento.setFechaEgreso(fechaEgreso);

            resultados.add(mantenimiento);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return resultados;
}

    public List<MantenimientoClass> getAllMantenimientos() {
        List<MantenimientoClass> mantenimientos = new ArrayList<>();
        String query = "SELECT * FROM MANTENIMIENTO";
        try (PreparedStatement statement = connection.prepareStatement(query); ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                int idMantenimiento = resultSet.getInt("ID_MANTENIMIENTO");
                int idHerramienta = resultSet.getInt("ID_HERRAMIENTA");
                Date fechaIngreso = resultSet.getDate("FECHA_INGRESO");
                Date fechaEgreso = resultSet.getDate("FECHA_EGRESO");

                MantenimientoClass mantenimiento = new MantenimientoClass(idMantenimiento, idHerramienta, fechaIngreso, fechaEgreso);
                mantenimientos.add(mantenimiento);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return mantenimientos;
    }
}