/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Models.EmpleadoClass;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author FMP
 */
public class EmpleadoDAO {
    
     private Connection connection;

    public EmpleadoDAO(Connection connection) {
        this.connection = connection;
    }

   public List<EmpleadoClass> obtenerTodosLosEmpleados() throws SQLException {
    List<EmpleadoClass> empleados = new ArrayList<>();
    String query = "SELECT * FROM EMPLEADOS";
    try (PreparedStatement stmt = connection.prepareStatement(query);
         ResultSet rs = stmt.executeQuery()) {
        while (rs.next()) {
            EmpleadoClass empleado = new EmpleadoClass();
            empleado.setNombre(rs.getString("NOMBRE"));
            empleado.setPrimerApellido(rs.getString("PRIMER_APELLIDO"));
            empleado.setSegundoApellido(rs.getString("SEGUNDO_APELLIDO"));
            empleado.setTelefono(rs.getString("TELEFONO"));
            empleado.setEmail(rs.getString("EMAIL"));
            empleado.setPuesto(rs.getString("PUESTO"));
            empleados.add(empleado);
        }
    }
    return empleados;
    }

    public void insertarEmpleado(EmpleadoClass empleado) throws SQLException {
        String query = "INSERT INTO EMPLEADOS (NOMBRE, PRIMER_APELLIDO, SEGUNDO_APELLIDO, TELEFONO, EMAIL, PUESTO) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, empleado.getNombre());
            stmt.setString(2, empleado.getPrimerApellido());
            stmt.setString(3, empleado.getSegundoApellido());
            stmt.setString(4, empleado.getTelefono());
            stmt.setString(5, empleado.getEmail());
            stmt.setString(6, empleado.getPuesto());
            stmt.executeUpdate();
        }
    }

    public void actualizarEmpleado(EmpleadoClass empleado) throws SQLException {
        String query = "UPDATE EMPLEADOS SET PRIMER_APELLIDO=?, SEGUNDO_APELLIDO=?, TELEFONO=?, EMAIL=?, PUESTO=? WHERE NOMBRE=?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, empleado.getPrimerApellido());
            stmt.setString(2, empleado.getSegundoApellido());
            stmt.setString(3, empleado.getTelefono());
            stmt.setString(4, empleado.getEmail());
            stmt.setString(5, empleado.getPuesto());
            stmt.setString(6, empleado.getNombre());
            stmt.executeUpdate();
        }
    }
}
    

