/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

import java.sql.Date;

/**
 *
 * @author FMP
 */
public class ProveedorClass {

    private int idProveedores;
    private String nombreEmpresa;
    private String productoSolicitado;
    private int cedulaEmpresa;
    private Date fechaPedido;

    public ProveedorClass() {
    }

    public ProveedorClass(int idProveedores, String nombreEmpresa, String productoSolicitado, int cedulaEmpresa, Date fechaPedido) {
        this.idProveedores = idProveedores;
        this.nombreEmpresa = nombreEmpresa;
        this.productoSolicitado = productoSolicitado;
        this.cedulaEmpresa = cedulaEmpresa;
        this.fechaPedido = fechaPedido;
    }

    public int getIdProveedores() {
        return this.idProveedores;
    }

    public void setIdProveedores(int idProveedores) {
        this.idProveedores = idProveedores;
    }

    public String getNombreEmpresa() {
        return this.nombreEmpresa;
    }

    public void setNombreEmpresa(String nombreEmpresa) {
        this.nombreEmpresa = nombreEmpresa;
    }

    public String getProductoSolicitado() {
        return this.productoSolicitado;
    }

    public void setProductoSolicitado(String productoSolicitado) {
        this.productoSolicitado = productoSolicitado;
    }

    public int getCedulaEmpresa() {
        return this.cedulaEmpresa;
    }

    public void setCedulaEmpresa(int cedulaEmpresa) {
        this.cedulaEmpresa = cedulaEmpresa;
    }

    public Date getFechaPedido() {
        return this.fechaPedido;
    }

    public void setFechaPedido(Date fechaPedido) {
        this.fechaPedido = fechaPedido;
    }

    @Override
    public String toString() {
        return "Proveedor{" + "idProveedores=" + idProveedores + ", nombreEmpresa=" + nombreEmpresa + ", productoSolicitado=" + productoSolicitado + ", cedulaEmpresa=" + cedulaEmpresa + ", fechaPedido=" + fechaPedido + '}';
    }
    
}
