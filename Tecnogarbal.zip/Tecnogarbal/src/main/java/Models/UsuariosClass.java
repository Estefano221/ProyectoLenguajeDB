/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

/**
 *
 * @author FMP
 */
public class UsuariosClass {
    private int idUsuario;
    private int idMateriales;
    private int contrasenia;
    private int confContrasenia;
    private String nombre;
    private int telefono;
    private String email;

    public UsuariosClass() {
    }

    public UsuariosClass(int idUsuario, int idMateriales, int contrasenia, int confContrasenia, String nombre, int telefono, String email) {
        this.idUsuario = idUsuario;
        this.idMateriales = idMateriales;
        this.contrasenia = contrasenia;
        this.confContrasenia = confContrasenia;
        this.nombre = nombre;
        this.telefono = telefono;
        this.email = email;
    }

    public int getIdUsuario() {
        return this.idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public int getIdMateriales() {
        return this.idMateriales;
    }

    public void setIdMateriales(int idMateriales) {
        this.idMateriales = idMateriales;
    }

    public int getContrasenia() {
        return this.contrasenia;
    }

    public void setContrasenia(int contrasenia) {
        this.contrasenia = contrasenia;
    }

    public int getConfContrasenia() {
        return this.confContrasenia;
    }

    public void setConfContrasenia(int confContrasenia) {
        this.confContrasenia = confContrasenia;
    }

    public String getNombre() {
        return this.nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getTelefono() {
        return this.telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public String getEmail() {
        return this.email;
    }

    public void setEmail(String email) {
        this.email = email;
    }


    
    }

    
