/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

/**
 *
 * @author FMP
 */
public class NotificacionClass {

    private int idNotificaciones;
    private int idHistorial;

    public NotificacionClass() {
    }

    public NotificacionClass(int idNotificaciones, int idHistorial) {
        this.idNotificaciones = idNotificaciones;
        this.idHistorial = idHistorial;
    }

    public int getIdNotificaciones() {
        return this.idNotificaciones;
    }

    public void setIdNotificaciones(int idNotificaciones) {
        this.idNotificaciones = idNotificaciones;
    }

    public int getIdHistorial() {
        return this.idHistorial;
    }

    public void setIdHistorial(int idHistorial) {
        this.idHistorial = idHistorial;
    }

    @Override
    public String toString() {
        return "Notificacion{" + "idNotificaciones=" + idNotificaciones + ", idHistorial=" + idHistorial + '}';
    }
    
}
