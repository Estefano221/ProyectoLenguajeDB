/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

import java.sql.Date;

/**
 *
 * @author FMP
 */
public class ReservasClass {

    private int idReservas;
    private int idEmpleado;
    private int idHerramienta;
    private Date fechaIngreso;
    private Date fechaEgreso;
    private String estadoHerramienta;

    public ReservasClass() {
    }

    public ReservasClass(int idReservas, int idEmpleado, int idHerramienta, Date fechaIngreso, Date fechaEgreso, String estadoHerramienta) {
        this.idReservas = idReservas;
        this.idEmpleado = idEmpleado;
        this.idHerramienta = idHerramienta;
        this.fechaIngreso = fechaIngreso;
        this.fechaEgreso = fechaEgreso;
        this.estadoHerramienta = estadoHerramienta;
    }

    public int getIdReservas() {
        return this.idReservas;
    }

    public void setIdReservas(int idReservas) {
        this.idReservas = idReservas;
    }

    public int getIdEmpleado() {
        return this.idEmpleado;
    }

    public void setIdEmpleado(int idEmpleado) {
        this.idEmpleado = idEmpleado;
    }

    public int getIdHerramienta() {
        return this.idHerramienta;
    }

    public void setIdHerramienta(int idHerramienta) {
        this.idHerramienta = idHerramienta;
    }

    public Date getFechaIngreso() {
        return this.fechaIngreso;
    }

    public void setFechaIngreso(Date fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

    public Date getFechaEgreso() {
        return this.fechaEgreso;
    }

    public void setFechaEgreso(Date fechaEgreso) {
        this.fechaEgreso = fechaEgreso;
    }

    public String getEstadoHerramienta() {
        return this.estadoHerramienta;
    }

    public void setEstadoHerramienta(String estadoHerramienta) {
        this.estadoHerramienta = estadoHerramienta;
    }

    @Override
    public String toString() {
        return "Reservas{" + "idReservas=" + idReservas + ", idEmpleado=" + idEmpleado + ", idHerramienta=" + idHerramienta + ", fechaIngreso=" + fechaIngreso + ", fechaEgreso=" + fechaEgreso + ", estadoHerramienta=" + estadoHerramienta + '}';
    }  

}
