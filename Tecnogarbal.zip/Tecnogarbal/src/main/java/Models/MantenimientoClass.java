/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

import java.sql.Date;

/**
 *
 * @author FMP
 */
public class MantenimientoClass {
    private int idMantenimiento;
    private int idHerramienta;
    private Date fechaIngreso;
    private Date fechaEgreso;

    public MantenimientoClass() {
        
    }

    public MantenimientoClass(int idMantenimiento, int idHerramienta, Date fechaIngreso, Date fechaEgreso) {
        this.idMantenimiento = idMantenimiento;
        this.idHerramienta = idHerramienta;
        this.fechaIngreso = fechaIngreso;
        this.fechaEgreso = fechaEgreso;
    }

    public int getIdMantenimiento() {
        return this.idMantenimiento;
    }

    public void setIdMantenimiento(int idMantenimiento) {
        this.idMantenimiento = idMantenimiento;
    }

    public int getIdHerramienta() {
        return this.idHerramienta;
    }

    public void setIdHerramienta(int idHerramienta) {
        this.idHerramienta = idHerramienta;
    }

    public Date getFechaIngreso() {
        return this.fechaIngreso;
    }

    public void setFechaIngreso(Date fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

    public Date getFechaEgreso() {
        return this.fechaEgreso;
    }

    public void setFechaEgreso(Date fechaEgreso) {
        this.fechaEgreso = fechaEgreso;
    }

    @Override
    public String toString() {
        return "Mantenimiento{" + "idMantenimiento=" + idMantenimiento + ", idHerramienta=" + idHerramienta + ", fechaIngreso=" + fechaIngreso + ", fechaEgreso=" + fechaEgreso + '}';
    }
    
    
    
    
}
