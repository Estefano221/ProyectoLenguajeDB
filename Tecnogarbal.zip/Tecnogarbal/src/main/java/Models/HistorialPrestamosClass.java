/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;


public class HistorialPrestamosClass {
    
    private int idHistorial;
    private int idEmpleado;
    private int idHerramienta;
    private int idReservas;
    private int idMantenimiento;

    public HistorialPrestamosClass() {
        
    }

    public HistorialPrestamosClass(int idHistorial, int idEmpleado, int idHerramienta, int idReservas, int idMantenimiento) {
        this.idHistorial = idHistorial;
        this.idEmpleado = idEmpleado;
        this.idHerramienta = idHerramienta;
        this.idReservas = idReservas;
        this.idMantenimiento = idMantenimiento;
    }

    public int getIdHistorial() {
        return idHistorial;
    }

    public void setIdHistorial(int idHistorial) {
        this.idHistorial = idHistorial;
    }

    public int getIdEmpleado() {
        return this.idEmpleado;
    }

    public void setIdEmpleado(int idEmpleado) {
        this.idEmpleado = idEmpleado;
    }

    public int getIdHerramienta() {
        return this.idHerramienta;
    }

    public void setIdHerramienta(int idHerramienta) {
        this.idHerramienta = idHerramienta;
    }

    public int getIdReservas() {
        return this.idReservas;
    }

    public void setIdReservas(int idReservas) {
        this.idReservas = idReservas;
    }

    public int getIdMantenimiento() {
        return this.idMantenimiento;
    }

    public void setIdMantenimiento(int idMantenimiento) {
        this.idMantenimiento = idMantenimiento;
    }

    @Override
    public String toString() {
        return "HistorialPrestamos{" + "idHistorial=" + idHistorial + ", idEmpleado=" + idEmpleado + ", idHerramienta=" + idHerramienta + ", idReservas=" + idReservas + ", idMantenimiento=" + idMantenimiento + '}';
    }
    
    
    
    
}
