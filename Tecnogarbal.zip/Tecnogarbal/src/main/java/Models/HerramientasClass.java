/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;


public class HerramientasClass {
    
    private int id;
    private String nombre;
    private int codigo;
    private String tipo;
    private String uso;
    private int idProveedor;

    public HerramientasClass() {
    }

    public HerramientasClass(int id, String nombre, int codigo, String tipo, String uso, int idProveedor) {
        this.id = id;
        this.nombre = nombre;
        this.codigo = codigo;
        this.tipo = tipo;
        this.uso = uso;
        this.idProveedor = idProveedor;
    }

    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return this.nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCodigo() {
        return this.codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getTipo() {
        return this.tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getUso() {
        return this.uso;
    }

    public void setUso(String uso) {
        this.uso = uso;
    }

    public int getIdProveedor() {
        return this.idProveedor;
    }

    public void setIdProveedor(int idProveedor) {
        this.idProveedor = idProveedor;
    }

    @Override
    public String toString() {
        return "Herramientas{" + "id=" + id + ", nombre=" + nombre + ", codigo=" + codigo + ", tipo=" + tipo + ", uso=" + uso + ", idProveedor=" + idProveedor + '}';
    }

  
    
}
