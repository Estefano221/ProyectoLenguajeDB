/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

import java.sql.Date;

/**
 *
 * @author FMP
 */
public class MaterialClass {
    
    private int idMateriales;
    private int idProveedores;
    private String nombre;
    private Date fechaIngreso;
    private Date fechaEgreso;
    private int tamano;
    private int cantidad;
    private String uso;
    private double precio;

    public MaterialClass() {
    }

    public MaterialClass(int idMateriales, int idProveedores, String nombre, Date fechaIngreso, Date fechaEgreso, int tamano, int cantidad, String uso, double precio) {
        this.idMateriales = idMateriales;
        this.idProveedores = idProveedores;
        this.nombre = nombre;
        this.fechaIngreso = fechaIngreso;
        this.fechaEgreso = fechaEgreso;
        this.tamano = tamano;
        this.cantidad = cantidad;
        this.uso = uso;
        this.precio = precio;
    }

    public int getIdMateriales() {
        return this.idMateriales;
    }

    public void setIdMateriales(int idMateriales) {
        this.idMateriales = idMateriales;
    }

    public int getIdProveedores() {
        return this.idProveedores;
    }

    public void setIdProveedores(int idProveedores) {
        this.idProveedores = idProveedores;
    }

    public String getNombre() {
        return this.nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Date getFechaIngreso() {
        return this.fechaIngreso;
    }

    public void setFechaIngreso(Date fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

    public Date getFechaEgreso() {
        return this.fechaEgreso;
    }

    public void setFechaEgreso(Date fechaEgreso) {
        this.fechaEgreso = fechaEgreso;
    }

    public int getTamano() {
        return this.tamano;
    }

    public void setTamano(int tamano) {
        this.tamano = tamano;
    }

    public int getCantidad() {
        return this.cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getUso() {
        return this.uso;
    }

    public void setUso(String uso) {
        this.uso = uso;
    }

    public double getPrecio() {
        return this.precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "Material{" + "idMateriales=" + idMateriales + ", idProveedores=" + idProveedores + ", nombre=" + nombre + ", fechaIngreso=" + fechaIngreso + ", fechaEgreso=" + fechaEgreso + ", tamano=" + tamano + ", cantidad=" + cantidad + ", uso=" + uso + ", precio=" + precio + '}';
    }
}
